import numpy
import netCDF4


def _get_statistics(array: numpy.array, axis: tuple, statistic: str = 'mean'):
    
    if statistic == 'mean':
        series = numpy.mean(array, axis)

    return series

def _add_dimensional_axis(axis_dimension, axis_dimension_values, computed_series, axis_dimension_type, datetime_to_string, datetime_format):    
    if axis_dimension_type == 'T':
        axis_values = []
        
        if 'calendar' in axis_dimension.__dict__:
            calendar = axis_dimension.__dict__['calendar']
        else:
            calendar = 'standard'
            
        if 'units' in axis_dimension.__dict__:
            units = axis_dimension.__dict__['units']
        else:
            units = 'days since 2000-1-1 0:0:0'
        
        new_axis_values = netCDF4.num2date(axis_dimension_values[:], units, calendar)
        
        if datetime_to_string:
            for date_value in new_axis_values:
                axis_values.append(date_value.strftime(datetime_format))
        
    else:
        axis_values = axis_dimension_values[:]
        
    if not numpy.array(axis_values).shape == computed_series.shape:
        computed_series = computed_series[:, 0, 0]
            
    series = numpy.column_stack((axis_values, computed_series))
    return series
