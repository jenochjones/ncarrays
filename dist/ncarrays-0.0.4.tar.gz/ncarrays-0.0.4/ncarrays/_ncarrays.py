import netCDF4
import numpy
import geopandas

from _geospatial_functions import _geojson_to_raster
from _post_processing import _get_statistics, _add_dimensional_axis
from _variable_interpretation import _determine_variable_types, _retrieve_sub_variables


class ARRAY:
    def __init__(self, opendap_url: str, variable: str or list, path_to_geojson: str or None = None, axis: list = [], dimensional_values: dict = {}, statistic: str = 'mean', datetime_to_string: bool = True, datetime_format: str = '%m-%d-%Y %H:%M:%S'):
        self.opendap_url = opendap_url
        self.variable = variable
        self.axis = axis
        self.path_to_geojson = path_to_geojson
        self.dimensional_values = dimensional_values
        self.statistic = statistic
        self.datetime_to_string = datetime_to_string
        self.datetime_format = datetime_format
        
        
    def get_series(self):
        main_variable = netCDF4.Dataset(self.opendap_url + '?' + self.variable).variables[self.variable]
        variables, variable_type_lists = _retrieve_sub_variables(self.opendap_url, main_variable, self.dimensional_values)
        variables[self.variable] = {'dataset': main_variable, 'datatype': 'D'}
        
        variables = _determine_variable_types(variables, variable_type_lists)
        dim_order = main_variable.dimensions
        
        y_dim = []
        x_dim = []
        subset_for_main_variable = []
        axis_dimension_type = None
        
        for dim in dim_order:
            if variables[dim]['datatype'] == 'Y':
                y_dim = variables[dim]['dataset'][:]
            elif variables[dim]['datatype'] == 'X':
                x_dim = variables[dim]['dataset'][:]
        
        if self.path_to_geojson is not None:
            if len(y_dim) >= 0 or len(x_dim) >= 0 :
                x_y_array, extents = _geojson_to_raster(self.path_to_geojson, x_dim, y_dim)
                
                if len(x_y_array) > 0:
                    sub_x_y_array = x_y_array[extents[0]:extents[1], extents[2]:extents[3]]
            else:
                print('X and Y dimensions not found')

            if len(x_y_array) <= 0:
                
                for dim in dim_order:
                    y_index = extents[0]
                    x_index = extents[1]
                    
                    if self.axis is not None:
                        if dim == self.axis:
                            axis_dimension_type = variables[dim]['datatype']
                        
                    if variables[dim]['datatype'] == 'Y':
                        subset_for_main_variable.append(slice(y_index - 1, y_index, 1))
                    elif variables[dim]['datatype'] == 'X':
                        subset_for_main_variable.append(slice(x_index - 1, x_index, 1))
                    else:
                        subset_for_main_variable.append(slice(None, None, 1))
                        
                subset_for_main_variable = tuple(subset_for_main_variable)
                
                series = main_variable[subset_for_main_variable]
                
            else:
                array_shape_for_tile = []
                dim_type_order = []
                
                for dim in dim_order:
                    print(dim)
                    dim_type_order.append(variables[dim]['datatype'])
                    
                    if self.axis is not None:
                        if dim == self.axis:
                            axis_dimension_type = variables[dim]['datatype']
                        
                    if variables[dim]['datatype'] == 'Y':
                        y_dim = variables[dim]['dataset'][:]
                        array_shape_for_tile.append(1)
                        subset_for_main_variable.append(slice(extents[0], extents[1], 1))
                    elif variables[dim]['datatype'] == 'X':
                        x_dim = variables[dim]['dataset'][:]
                        array_shape_for_tile.append(1)
                        subset_for_main_variable.append(slice(extents[2], extents[3], 1))
                    else:
                        if dim in self.dimensional_values:
                            
                            subset_for_main_variable.append(self.dimensional_values[dim])
                            
                            if isinstance(self.dimensional_values[dim], int):
                                array_shape_for_tile.append(1)
                            elif isinstance(self.dimensional_values[dim], slice):
                                array_shape_for_tile.append(len(variables[dim]['dataset'][self.dimensional_values[dim]]))
                            else:
                                array_shape_for_tile.append(len(variables[dim]['dataset'][:]))
                        else:
                            subset_for_main_variable.append(slice(None, None, 1))
                            array_shape_for_tile.append(len(variables[dim]['dataset'][:]))
                
            array_shape_for_tile = tuple(array_shape_for_tile)
            dim_type_order = tuple(dim_type_order)
            subset_for_main_variable = tuple(subset_for_main_variable)
            
            sub_main_array = main_variable[subset_for_main_variable]
            full_dimensional_array = numpy.tile(sub_x_y_array, array_shape_for_tile)
            
            masked_array = full_dimensional_array * sub_main_array
            
            axis_list = []
            
            for index, dim in enumerate(dim_order):
                if dim not in self.axis:
                    axis_list.append(index)
            
            axis_tuple = tuple(axis_list)
            
            series = _get_statistics(masked_array, axis_tuple, self.statistic)
            
        else:
            subset_for_main_variable = []
            
            for dim in dim_order:
                
                if self.axis is not None:
                    if dim == self.axis:
                        axis_dimension_type = variables[dim]['datatype']
                
                if dim in self.dimensional_values:
                    subset_for_main_variable.append(self.dimensional_values[dim])
                else:
                    subset_for_main_variable.append(slice(None, None, 1))
                
            subset_for_main_variable = tuple(subset_for_main_variable)
            sub_main_array = main_variable[subset_for_main_variable]
            
            axis_list = []
            
            for index, dim in enumerate(dim_order):
                if dim not in self.axis:
                    axis_list.append(index)
            
            axis_tuple = tuple(axis_list)
            
            series = _get_statistics(sub_main_array, axis_tuple, self.statistic)
            
                
        
        if (isinstance(self.axis, str) and self.axis is not None) or (isinstance(self.axis, list) and len(self.axis) == 1):
            if isinstance(self.axis, list):
                axis_name = self.axis[0]
            else:
                axis_name = self.axis
            if axis_name in self.dimensional_values:
                axis_dimension_values = variables[axis_name]['dataset'][self.dimensional_values[axis_name]]
            else:
                axis_dimension_values = variables[axis_name]['dataset'][:]
            
            series = _add_dimensional_axis(variables[axis_name]['dataset'], axis_dimension_values, series, axis_dimension_type, self.datetime_to_string, self.datetime_format)
        elif isinstance(self.axis, str) and self.axis is not None:
            print('still figuring this out')
        
        return series


def convert_shapefile_to_geojson(path_to_shapefile, path_to_geojson):
    geojson = geopandas.read_file(path_to_shapefile)
    geojson.to_file(path_to_geojson, driver="GeoJSON")
