#NCARRAYS

##Extract data from netCDF files using OPeNDAP

###Installation
<p>To install ncbuild run "pip install ncarrays" in your terminal.</p>
